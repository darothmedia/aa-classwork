class Array
  def my_each(&proc)
    i = 0
    while i < self.length
      proc.call(self[i])
      i += 1
    end
    self
  end

  def my_select(&proc)
    arr_new = []
    self.my_each do |ele|
      arr_new << ele if proc.call(ele)
    end
    #arr_new << my_each(&proc) if my_each(&proc) == true     #{ |ele| arr_new << ele if proc.call(ele)}
    arr_new
  end

  def my_reject(&proc)
    arr_new = []
    self.my_each do |ele|
      arr_new << ele unless proc.call(ele)
    end
    arr_new
  end

  def my_any?(&proc)
    self.my_each do |ele|
      return true if proc.call(ele)
    end
    return false
  end

  def my_all?(&proc)
    self.my_each do |ele|
      return false if !proc.call(ele)
    end
    return true
  end

  def my_flatten
    values = []
    return self[0] if self.length == 1
    self.my_each do |ele|
      if !ele.is_a?(Integer)
        values.concat(ele.my_flatten)
      else
        values << ele # exit strat
      end
    end
    values
  end

  def my_zip(*arrays)
    new_arr = Array.new(self.length){Array.new(0)}
    self.each.with_index {|ele, idx| new_arr[idx] << ele}
    arrays.each do |array|
      difference = self.length - array.length
      if difference > 0
        difference.times {array << nil}
      end
      difference.times{array << nil}
      array.each.with_index do |ele, idx| 
        if idx < new_arr.length
          new_arr[idx] << ele
        end
      end
    end
    new_arr
  end

  def my_rotate(num=1)
    #if num.negative?
    #  (num + 4).times do
    #    last = self.pop
    #    self.unshift(last)
    #  end
    #else
  
    if num >= self.length
      (num % 4).times do
        first = self.shift
        self.push(first)
      end
    else
      (num).times do
        first = self.shift
        self.push(first)
      end
    end
    self
  end

  def my_join(separator="")
    new_str = ""
    self.each do |ele|
      new_str << ele + separator
    end
    new_str
  end

  def my_reverse
    new_arr = []
    i = self.length - 1
    while i >= 0
      new_arr << self[i]
      i -=1
    end
    new_arr
  end


end

p [ "a", "b", "c" ].my_reverse   #=> ["c", "b", "a"]
p [ 1 ].my_reverse               #=> [1]


#a = [ "a", "b", "c", "d" ]
#p a.my_join         # => "abcd"
#p a.my_join("$")    # => "a$b$c$d"

# a = [ "a", "b", "c", "d" ]
# p a.my_rotate         #=> ["b", "c", "d", "a"]
# p a.my_rotate(2)      #=> ["c", "d", "a", "b"]
# # p a.my_rotate(-3)     #=> ["b", "c", "d", "a"]
# p a.my_rotate(15)     #=> ["d", "a", "b", "c"]



# [1, 2, 3, 4, 5, 6
 #[[[7]], 8]]

# return_value = [1, 2, 3].my_each do |num|
#   puts num
# end.my_each do |num|
#   puts num
# end
# # => 1
#      2
#      3
#      1
#      2
#      3
# 
# p return_value  # => [1, 2, 3]

# a = [1, 2, 3]
# p a.my_select { |num| num > 1 } # => [2, 3]
# p a.my_select { |num| num == 4 } # => []

# a = [1, 2, 3]
# p a.my_reject { |num| num > 1 } # => [1]
# p a.my_reject { |num| num == 4 } # => [1, 2, 3]

# a = [1, 2, 3]
# p a.my_any? { |num| num > 1 } # => true
# p a.my_any? { |num| num == 4 } # => false
# p a.my_all? { |num| num > 1 } # => false
# p a.my_all? { |num| num < 4 } # => true

# [1, 2, 3, [4, [5, 6]], [[[7]], 8]].my_flatten # => [1, 2, 3, 4, 5, 6, 7, 8]
#a = [ 4, 5, 6 ]
#b = [ 7, 8, 9 ]
#p [1, 2, 3].my_zip(a, b) # => [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
#p a.my_zip([1,2], [8])   # => [[4, 1, 8], [5, 2, nil], [6, nil, nil]]
#p [1, 2].my_zip(a, b)    # => [[1, 4, 7], [2, 5, 8]]
#
#c = [10, 11, 12]
#d = [13, 14, 15]
#p [1, 2].my_zip(a, b, c, d)    # => [[1, 4, 7, 10, 13], [2, 5, 8, 11, 14]]