require_relative "player"

class Game
  attr_reader :dictionary
  def initialize(*players)
    @fragment = "" 
    @players = players
    @dictionary = Hash.new(0)
    File.readlines("dictionary.txt").each do |word|
      @dictionary[word.chomp] = 0
    end
    @current_player = @players[0]
  end
  
  

  def current_player
    
  end

  def previous_player

  end

  def next_player! # mutates current player and previous player

  end

  def take_turn(player)
    if valid_play?(@current_player.get_input)
      
    end
  end

  def valid_play?(string)
    if !("a".."z").include?(string)
      raise "Not in the alphabet!"
      return false
    elsif !@dictionary.keys.include(@fragment + string)
      raise "No words found with this fragment!"
      return false
    else
      return true
    end
  end

  def play_round
    take_turn(@current_player)
  end

end
#hash = Hash.new(0)

n = Game.new
p n.dictionary.has_key?("dog")