

class Player
  
  def initialize(name)
    @name = name
  end

  def guess
    puts "Enter a letter: "
    gets.chomp.downcase
  end

  def alert_invalid_guess

  end







end